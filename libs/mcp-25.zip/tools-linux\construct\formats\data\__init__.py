"""
all sorts of raw data serialization (tcpdump capture files, etc.)
"""
