#!/bin/bash
python runtime/decompile.py conf/mcp.cfg
