"""
audio file formats (wav, mp3, ogg, midi, ...)
"""

